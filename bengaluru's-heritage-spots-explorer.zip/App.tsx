
import React, { useState } from 'react';
import { HeritageScreen } from './components/HeritageScreen';
import { ChatbotScreen } from './components/ChatbotScreen';

type Screen = 'heritage' | 'chatbot';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('heritage');

  const navigateToChat = () => setCurrentScreen('chatbot');
  const navigateToHeritage = () => setCurrentScreen('heritage');

  return (
    <div className="antialiased">
      {currentScreen === 'heritage' && <HeritageScreen onNavigateToChat={navigateToChat} />}
      {currentScreen === 'chatbot' && <ChatbotScreen onNavigateBack={navigateToHeritage} />}
    </div>
  );
};

export default App;
