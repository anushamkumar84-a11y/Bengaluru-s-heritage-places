
export interface HeritageSpot {
  id: number;
  name: {
    en: string;
    kn: string;
  };
  location: string;
  specialty: {
    en: string;
    kn: string;
  };
  image: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
}
