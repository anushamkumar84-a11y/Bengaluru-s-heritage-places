
import type { HeritageSpot } from './types';

export const HERITAGE_SPOTS: HeritageSpot[] = [
  {
    id: 1,
    name: {
      en: 'Vidhana Soudha',
      kn: 'ವಿಧಾನಸೌಧ',
    },
    location: 'Ambedkar Veedhi, Sampangi Rama Nagara',
    specialty: {
      en: 'A magnificent example of Neo-Dravidian architecture, it is the seat of the state legislature of Karnataka.',
      kn: 'ನಿಯೋ-ದ್ರಾವಿಡ ವಾಸ್ತುಶಿಲ್ಪದ ಭವ್ಯ ಉದಾಹರಣೆ, ಇದು ಕರ್ನಾಟಕದ ರಾಜ್ಯ ಶಾಸಕಾಂಗದ ಸ್ಥಾನವಾಗಿದೆ.',
    },
    image: 'https://picsum.photos/seed/vidhana/600/400',
  },
  {
    id: 2,
    name: {
      en: 'Bangalore Palace',
      kn: 'ಬೆಂಗಳೂರು ಅರಮನೆ',
    },
    location: 'Vasanth Nagar, Bengaluru',
    specialty: {
      en: 'Built in Tudor Revival style architecture, it is known for its beautiful carvings and paintings.',
      kn: 'ಟ್ಯೂಡರ್ ರಿವೈವಲ್ ಶೈಲಿಯ ವಾಸ್ತುಶಿಲ್ಪದಲ್ಲಿ ನಿರ್ಮಿಸಲಾಗಿದೆ, ಇದು ಸುಂದರವಾದ ಕೆತ್ತನೆಗಳು ಮತ್ತು ವರ್ಣಚಿತ್ರಗಳಿಗೆ ಹೆಸರುವಾಸಿಯಾಗಿದೆ.',
    },
    image: 'https://picsum.photos/seed/palace/600/400',
  },
  {
    id: 3,
    name: {
      en: 'Tipu Sultan\'s Summer Palace',
      kn: 'ಟಿಪ್ಪು ಸುಲ್ತಾನ್ ಬೇಸಿಗೆ ಅರಮನೆ',
    },
    location: 'Albert Victor Road, Chamrajpet',
    specialty: {
      en: 'An example of Indo-Islamic architecture, this palace was the summer residence of the Mysorean ruler Tipu Sultan.',
      kn: 'ಇಂಡೋ-ಇಸ್ಲಾಮಿಕ್ ವಾಸ್ತುಶಿಲ್ಪದ ಉದಾಹರಣೆಯಾದ ಈ ಅರಮನೆಯು ಮೈಸೂರು ದೊರೆ ಟಿಪ್ಪು ಸುಲ್ತಾನನ ಬೇಸಿಗೆ ನಿವಾಸವಾಗಿತ್ತು.',
    },
    image: 'https://picsum.photos/seed/tipu/600/400',
  },
  {
    id: 4,
    name: {
      en: 'Lalbagh Botanical Garden',
      kn: 'ಲಾಲ್‌ಬಾಗ್ ಬೊಟಾನಿಕಲ್ ಗಾರ್ಡನ್',
    },
    location: 'Mavalli, Bengaluru',
    specialty: {
      en: 'Home to a famous glass house and a vast collection of tropical plants, it hosts biannual flower shows.',
      kn: 'ಪ್ರಸಿದ್ಧ ಗಾಜಿನ ಮನೆ ಮತ್ತು ಉಷ್ಣವಲಯದ ಸಸ್ಯಗಳ ವ್ಯಾಪಕ ಸಂಗ್ರಹಕ್ಕೆ ನೆಲೆಯಾಗಿದೆ, ಇದು ದ್ವೈವಾರ್ಷಿಕ ಹೂವಿನ ಪ್ರದರ್ಶನಗಳನ್ನು ಆಯೋಜಿಸುತ್ತದೆ.',
    },
    image: 'https://picsum.photos/seed/lalbagh/600/400',
  },
];

export const CHATBOT_SUGGESTIONS: string[] = [
    'Tell me about Vidhana Soudha',
    'What is special about Bangalore Palace?',
    'Who built Tipu Sultan\'s Palace?',
    'Give me a summary of Bengaluru\'s history',
];
