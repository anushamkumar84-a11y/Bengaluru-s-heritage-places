
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';
import type { ChatMessage } from '../types';
import { CHATBOT_SUGGESTIONS } from '../constants';
import { BackIcon } from './icons/BackIcon';
import { SendIcon } from './icons/SendIcon';

interface ChatbotScreenProps {
  onNavigateBack: () => void;
}

export const ChatbotScreen: React.FC<ChatbotScreenProps> = ({ onNavigateBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      chatRef.current = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: "You are a friendly and knowledgeable tour guide for Bengaluru's heritage spots. Your name is Namma Guide. Answer only questions related to Bengaluru's history, heritage, culture, and famous locations. If asked about anything else, politely decline and steer the conversation back to Bengaluru heritage. Provide information about locations when asked. Keep answers concise and engaging.",
        }
      });
      setMessages([{ id: 'init', text: "Hello! I'm Namma Guide. Ask me anything about Bengaluru's wonderful heritage spots!", sender: 'bot' }]);
    } catch (e) {
        setError("Failed to initialize the chatbot. Please check the API key.");
        console.error(e);
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (messageText?: string) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMessage: ChatMessage = { id: Date.now().toString(), text: textToSend, sender: 'user' };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
        if (!chatRef.current) {
            throw new Error("Chat session not initialized.");
        }
      const response = await chatRef.current.sendMessage({ message: textToSend });
      const botMessage: ChatMessage = { id: (Date.now() + 1).toString(), text: response.text, sender: 'bot' };
      setMessages((prev) => [...prev, botMessage]);
    } catch (e: any) {
      setError('Sorry, I encountered an error. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSuggestionClick = (suggestion: string) => {
      setInput(suggestion);
      handleSend(suggestion);
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-yellow-300 via-red-500 to-yellow-400">
      <header className="flex items-center p-4 bg-red-600 text-white shadow-md z-10">
        <button onClick={onNavigateBack} className="p-2 rounded-full hover:bg-red-700">
          <BackIcon className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-bold ml-4">Heritage Chatbot</h1>
      </header>

      <main className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs md:max-w-md lg:max-w-2xl px-4 py-2 rounded-2xl shadow ${
                msg.sender === 'user'
                  ? 'bg-yellow-200 text-red-900 rounded-br-none'
                  : 'bg-white text-gray-800 rounded-bl-none'
              }`}
            >
              <p className="whitespace-pre-wrap">{msg.text}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="max-w-xs px-4 py-2 rounded-2xl shadow bg-white text-gray-800 rounded-bl-none">
                <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse delay-75"></div>
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse delay-150"></div>
                </div>
             </div>
          </div>
        )}
        {error && <p className="text-center text-white font-semibold">{error}</p>}
        <div ref={messagesEndRef} />
      </main>
      
      <div className="p-4 bg-white/20 backdrop-blur-sm">
        <div className="flex flex-wrap gap-2 mb-2 justify-center">
            {CHATBOT_SUGGESTIONS.map(suggestion => (
                <button 
                    key={suggestion}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="px-3 py-1 bg-white/80 text-red-700 rounded-full text-sm hover:bg-white transition-colors"
                >
                    {suggestion}
                </button>
            ))}
        </div>
        <div className="flex items-center bg-white rounded-full shadow-inner p-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about a heritage spot..."
            className="flex-1 bg-transparent px-4 py-2 text-gray-800 placeholder-gray-500 focus:outline-none"
            disabled={isLoading}
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || !input.trim()}
            className="p-2 rounded-full bg-red-600 text-white disabled:bg-gray-400 hover:bg-red-700 transition-colors"
          >
            <SendIcon className="h-6 w-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
