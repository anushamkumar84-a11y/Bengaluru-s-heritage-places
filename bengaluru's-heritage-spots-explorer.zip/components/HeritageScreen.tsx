
import React, { useState } from 'react';
import { HERITAGE_SPOTS } from '../constants';
import { HeritageCard } from './HeritageCard';
import { ChatIcon } from './icons/ChatIcon';
import { LogoIcon } from './icons/LogoIcon';

interface HeritageScreenProps {
  onNavigateToChat: () => void;
}

export const HeritageScreen: React.FC<HeritageScreenProps> = ({ onNavigateToChat }) => {
  const [language, setLanguage] = useState<'en' | 'kn'>('en');

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-yellow-300 via-red-500 to-yellow-400 text-gray-800 p-4 sm:p-6 md:p-8">
      <header className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white text-shadow-lg drop-shadow-md">
          {language === 'en' ? "Bengaluru's Heritage Spots" : 'ಬೆಂಗಳೂರಿನ ಪಾರಂಪರಿಕ ತಾಣಗಳು'}
        </h1>
        <div className="mt-4 flex justify-center gap-4">
          <button
            onClick={() => setLanguage('en')}
            className={`px-4 py-2 rounded-full font-semibold transition-colors ${
              language === 'en' ? 'bg-white text-red-600 shadow-md' : 'bg-red-600/50 text-white'
            }`}
          >
            English
          </button>
          <button
            onClick={() => setLanguage('kn')}
            className={`px-4 py-2 rounded-full font-semibold transition-colors ${
              language === 'kn' ? 'bg-white text-red-600 shadow-md' : 'bg-red-600/50 text-white'
            }`}
          >
            ಕನ್ನಡ
          </button>
        </div>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-24">
        {HERITAGE_SPOTS.map((spot) => (
          <HeritageCard key={spot.id} spot={spot} language={language} />
        ))}
      </main>

      <footer className="text-center mt-12 pb-4">
         <LogoIcon className="h-16 w-16 mx-auto text-white/80" />
      </footer>

      <button
        onClick={onNavigateToChat}
        className="fixed bottom-6 right-6 bg-yellow-400 text-red-800 p-4 rounded-full shadow-2xl hover:bg-yellow-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 transform hover:scale-110 transition-transform"
        aria-label="Open Chatbot"
      >
        <ChatIcon className="h-8 w-8" />
      </button>
    </div>
  );
};
