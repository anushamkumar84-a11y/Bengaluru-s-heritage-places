
import React from 'react';
import type { HeritageSpot } from '../types';

interface HeritageCardProps {
  spot: HeritageSpot;
  language: 'en' | 'kn';
}

export const HeritageCard: React.FC<HeritageCardProps> = ({ spot, language }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300 ease-in-out">
      <img className="w-full h-48 object-cover" src={spot.image} alt={spot.name[language]} />
      <div className="p-6">
        <h3 className="text-2xl font-bold text-red-800 mb-2">{spot.name[language]}</h3>
        <p className="text-sm font-semibold text-gray-600 mb-3">{spot.location}</p>
        <p className="text-gray-700 text-base">{spot.specialty[language]}</p>
      </div>
    </div>
  );
};
